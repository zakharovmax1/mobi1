//
//  ContentView.swift
//  mobi1
//
//  Created by admin on 15.01.2021.
//
import SwiftUI

struct ContentView: View {
    @State var isShown = false
    var body: some View {
        NavigationView   {
            ZStack {
                Color(red: 0.17, green: 0.24, blue: 0.31).ignoresSafeArea()
                VStack {
                    Image("logo")
                        .resizable()
                        .aspectRatio(contentMode:.fill)
                        .frame(width: 100, height: 100)
                        .clipShape(Circle()).overlay(Circle().stroke(lineWidth: 5))
                    Text("Mobi Life")
                        .font(.title2)
                        .fontWeight(.heavy)
                    Text("Сервисный центр")
                        .font(.headline)
                        .fontWeight(.light)
                    Divider()
                    Button(action:{
                        isShown = true
                    }) {
                        NavigationLink(destination: IPhoneView(isShown: $isShown), isActive: $isShown)
                        {
                            Card(image: "iphone", message: "Мобильные телефоны")
                        }
                        
                    }
                    Button(action:{
                        isShown = true
                    }) {
                        NavigationLink(destination: AirPodsView(isShown: $isShown), isActive: $isShown)  {
                            Card(image: "airpodspro", message: "Наушники")
                        }
                        
                    }
                    Button(action:{}) {
                        NavigationLink(destination: IPadView(isShown: $isShown), isActive: $isShown) {
                            Card(image: "ipad.homebutton", message: "Планшеты")
                        }
                        
                    }
                    Button(action:{}) {
                        NavigationLink(destination: WatchView(isShown: $isShown), isActive: $isShown) {
                            Card(image: "applewatch.watchface", message: "Смарт-часы")
                        }
                        
                    }
                    Button(action:{}) {
                        NavigationLink(destination: HomePodView(isShown: $isShown), isActive: $isShown) {
                            Card(image: "hifispeaker.and.homepod.fill", message: "Колонки")
                        }
                        
                    }
                    
                    Button(action:{}) {
                        NavigationLink(destination: LaptopView(isShown: $isShown), isActive: $isShown) {
                            Card(image: "laptopcomputer.and.iphone", message: "Контактная информация")
                        }
                        
                    }
                }
                .foregroundColor(.white)
            }
            .navigationBarHidden(true)
        }
    }
}

struct IPhoneView: View
{
    @Binding var isShown: Bool
    var body: some View
    {
        ZStack(alignment: .topLeading)
        {
            Color(red: 0.17, green: 0.24, blue:0.31).ignoresSafeArea()
            
            VStack {
                Image(systemName: "apps.iphone")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 40, height: 60, alignment: .topLeading)
                    .foregroundColor(.white)
                Text("IPhone")
                    .foregroundColor(Color.white)
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "iphone.slash")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 25)
                        Text("Ремонт экрана")
                                    .font(.title3)
                                    
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName:"candybarphone")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 20, height: 25)
                        Text("Ремонт кнопок")
                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "speaker.wave.3")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 20)
                        Text("Ремонт динамиков")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "battery.100.bolt")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 17)
                        Text("Замена батареи")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "rectangle.portrait.arrowtriangle.2.inward")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 17)
                        Text("Разъемы")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })

                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "camera.badge.ellipsis")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 32, height: 17)
                        Text("Ремонт камер")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "cloud.rain")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Чистка после воды")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                
            }
            .navigationBarHidden(true)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            Button(action: {
                isShown = false
            }, label: {
                Image(systemName: "arrow.uturn.backward.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
            })
            .padding()
        }
    }
}

struct AirPodsView: View
{
    @Binding var isShown: Bool
    var body: some View {
        ZStack(alignment: .topLeading)
        {
            Color(red: 0.17, green: 0.24, blue:0.31).ignoresSafeArea()
            VStack
            {
                Image(systemName: "headphones")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 60, height: 53, alignment: .topLeading)
                    .foregroundColor(.white)
                    
                Text("Headphones")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.white)
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "hifispeaker.2")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Ремонт динамиков")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "earpods")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Ремонт проводов наушников")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "music.mic")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Ремонт микрофона")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "mappin.and.ellipse")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 17)
                        Text("Ремонт штекера наушников")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "wrench.and.screwdriver")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 17)
                        Text("Диагностика в случае отказа")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "ipod")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 20, height: 15)
                        Text("Ремонт плееров, IPod")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "paintbrush")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 20, height: 15)
                        Text("Чистка")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
            }
            .navigationBarHidden(true)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            Button(action: {
                isShown = false
            }, label: {
                Image(systemName: "arrow.uturn.backward.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
            })
            .padding()
        }
    }
    
}
struct IPadView: View
{
    @Binding var isShown: Bool
    var body: some View
    {
        ZStack(alignment: .topLeading)
        {
            Color(red: 0.17, green: 0.24, blue:0.31).ignoresSafeArea()
            VStack {
               
                Image(systemName: "apps.ipad")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 40, height: 60, alignment: .topLeading)
                    .foregroundColor(.white)
                Text("IPad")
                    .foregroundColor(Color.white)
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "apps.ipad.landscape")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 25)
                        Text("Ремонт экрана")
                                    .font(.title3)
                                    
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName:"gearshape.2")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 20, height: 25)
                        Text("Ремонт кнопок")
                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "speaker.wave.3")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 20)
                        Text("Ремонт динамиков")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "battery.100.bolt")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 17)
                        Text("Замена батареи")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "rectangle.portrait.arrowtriangle.2.inward")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 17)
                        Text("Разъемы")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })

                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "camera.badge.ellipsis")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 32, height: 17)
                        Text("Ремонт камер")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "cloud.rain")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Чистка после воды")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                
                
            }
            .navigationBarHidden(true)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            Button(action: {
                isShown = false
            }, label: {
                Image(systemName: "arrow.uturn.backward.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
            })
            .padding()
        }
    }
}
struct WatchView: View
{
    @Binding var isShown: Bool
    var body: some View
    {
        ZStack(alignment: .topLeading)
        {
            Color(red: 0.17, green: 0.24, blue:0.31).ignoresSafeArea()
            VStack {
               
                Image(systemName: "applewatch.watchface")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 40, height: 60, alignment: .topLeading)
                    .foregroundColor(.white)
                Text("AppleWatch")
                    .foregroundColor(Color.white)
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "exclamationmark.applewatch")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 20)
                        Text("Замена экрана")
                                    .font(.title3)
                                    
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName:"gearshape.2")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 30)
                        Text("Ремонт кнопок")
                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "applewatch.radiowaves.left.and.right")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 40, height: 22)
                        Text("Ремонт динамиков")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "battery.100.bolt")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 17)
                        Text("Замена батареи")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "lock.applewatch")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Настройка, разблокировка")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })

                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "camera.badge.ellipsis")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 32, height: 17)
                        Text("Ремонт камер")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "cloud.rain")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Чистка после воды")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                
                
                
            }
            .navigationBarHidden(true)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            Button(action: {
                isShown = false
            }, label: {
                Image(systemName: "arrow.uturn.backward.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
            })
            .padding()
        }
    }
}
struct HomePodView: View
{
    @Binding var isShown: Bool
    var body: some View
    {
        ZStack(alignment: .topLeading)
        {
            Color(red: 0.17, green: 0.24, blue:0.31).ignoresSafeArea()
            VStack {
               
                Image(systemName: "hifispeaker.and.homepod")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 50, height: 55, alignment: .topLeading)
                    .foregroundColor(.white)
                Text("HomePod")
                    .foregroundColor(Color.white)
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "hifispeaker")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 20)
                        Text("Замена динамиков")
                                    .font(.title3)
                                    
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName:"gearshape.2")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 30)
                        Text("Ремонт кнопок")
                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
              
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame( height:50)
                    .overlay(HStack {
                        Image(systemName: "battery.100.bolt")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 30, height: 17)
                        Text("Замена батареи")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "bolt")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 23, height: 15)
                        Text("Гнездо зарядки")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })

                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "speaker.zzz")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 32, height: 17)
                        Text("Замена усилителя")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "cloud.rain")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Чистка после воды")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
            
                
            }
            .navigationBarHidden(true)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            Button(action: {
                isShown = false
            }, label: {
                Image(systemName: "arrow.uturn.backward.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
            })
            .padding()
        }
    }
}
struct LaptopView: View
{
    @Binding var isShown: Bool
    var body: some View
    {
        ZStack(alignment: .topLeading)
        {
            Color(red: 0.17, green: 0.24, blue:0.31).ignoresSafeArea()
            VStack {
               
                Image(systemName: "person.crop.circle.badge.questionmark")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 90, height:90)
                    .foregroundColor(.white)
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "phone.bubble.left")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("Демченко Дмитрий")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "phone")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("+380638051282")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })

                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(height:50)
                    .overlay(HStack {
                        Image(systemName: "map")
                            .resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 25, height: 15)
                        Text("ул. 23 сентября")
                                    .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31))
                    })

            }
            .navigationBarHidden(true)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            Button(action: {
                isShown = false
            }, label: {
                Image(systemName: "arrow.uturn.backward.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
            })
            .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Card: View {
    let image: String
    let message: String
    var body: some View {
        RoundedRectangle(cornerRadius: 20).padding([.top, .leading, .trailing], 2.0)
            .frame(width:320,height:50).overlay(HStack {Image(systemName: image)
                Text(message)
                    .fontWeight(.semibold)
            }.foregroundColor(Color(red: 0.17, green: 0.24, blue: 0.31)))
    }
}
