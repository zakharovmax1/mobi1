//
//  mobi1App.swift
//  mobi1
//
//  Created by admin on 15.01.2021.
//

import SwiftUI

@main
struct mobi1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
